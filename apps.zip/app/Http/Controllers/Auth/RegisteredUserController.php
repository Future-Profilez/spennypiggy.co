<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Jobs\CreateStripeCustomer;
use App\Models\User;
use App\Providers\RouteServiceProvider;
use Illuminate\Auth\Events\Registered;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules;
use Inertia\Inertia;
use Inertia\Response;
use Ramsey\Uuid\Uuid;
use App\Jobs\WelcomeUser;
use Carbon\Carbon;

class RegisteredUserController extends Controller
{
    /**
     * Display the registration view.
     */
    public function create(): Response
    {
        return Inertia::render('Auth/Register');
    }

    /**
     * Handle an incoming registration request.
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    public function store(Request $request): RedirectResponse
    {
        $request->validate([
            'name' => [
                'required',
                'string',
                'max:255'
            ],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users,email'],
            'password' => ['required', 'confirmed', Rules\Password::defaults()],
            'username' => ['required', 'string', 'lowercase', 'max:20', 'unique:users,username'],
        ]);

        $user = User::create([
            'name' => $request->name,
            'email' => strtolower($request->email),
            'username' => $request->username,
            'password' => Hash::make($request->password),
        ]);

        // CreateStripeCustomer::dispatch($user);
        event(new Registered($user));

        Auth::login($user);

        //send email
        WelcomeUser::dispatch($user);

        return redirect(route("user.show", [$user->username]))->with("success", "Registration successfull.");
    }

    /**
     * Check if username available
     *
     * @param Request $request
     * @return Response
     */
    public function checkUsername(Request $request)
    {

        $request->validate([
            "username" => [
                "required",
                "string",
                "min:5",
                "max:20"
            ]
        ]);

        $exist = User::whereUsername($request->username)->first();
        return response()->json([
            "available" => empty($exist)
        ]);
    }

    /* get verify email page */
    public function getVerifyEmailPage($uuid)
    {
        try {
            $user = User::whereUuid($uuid)->first();
            $id = $user->id;
            return view('verify-email', compact('id'));
        } catch (\Throwable $th) {
            //throw $th;
        }
    }

    /* verify email */
    public function verifyEmail(Request $request)
    {
        try {
            $verify = User::whereId($request->id)->update([
                'email_verified_at' => Carbon::now(),
            ]);
            if (!empty($verify)) {
                print_r('email verify');
                die;
            } else {
                print_r('unable to verify your email');
                die;
            }
        } catch (\Throwable $th) {
            //throw $th;
        }
    }
}
